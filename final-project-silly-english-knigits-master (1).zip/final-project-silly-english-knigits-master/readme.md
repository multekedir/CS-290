Your mother was a hamster and your father smelled of elderberries!
Now go away or I shall taunt you a second time!
