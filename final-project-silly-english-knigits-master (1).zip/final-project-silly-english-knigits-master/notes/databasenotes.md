#Database tables and stuff
 * Departments (ID, Name, Location, Positions)
 * Position (ID, Name, DefaultSalary)
 * People (ID, Name, Department, Salary, Email, Position, LocationOverried)
 * Users (ID, Username, Password, Email, Picture)

	People need to also have a list of previous positions
