Static files should be served from here.
